void settextcolor(int color, int bgcolor);
void gotoxy(int x, int y);
void gotoxytext(int x, int y, char *string);
