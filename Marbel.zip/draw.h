#pragma once

void Explain();
void GameDice();
void GameBoard();
void DiceShape(int dice);