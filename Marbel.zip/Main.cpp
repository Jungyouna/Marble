#include <stdio.h>
#include "start.h"

void main() {
	StartGame();
}
