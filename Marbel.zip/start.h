#pragma once

void StartGame();